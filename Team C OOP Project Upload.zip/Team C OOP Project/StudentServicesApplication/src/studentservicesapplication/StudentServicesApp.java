/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package studentservicesapplication;

/**
 *
 * @author x12112267
 */
public class StudentServicesApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
       MainPage myMainPage = new MainPage();
       myMainPage.setVisible(true);
       myMainPage.setTitle("Main Page");
       
       
    }
}
