/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package computersupportapplication;

/**
 *
 * @author John Mc Dermott
 */
public class ComputerSupportApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
       ComputerSupportGUI myCSGUI = new ComputerSupportGUI();
       myCSGUI.setVisible(true);
    
    }
}

