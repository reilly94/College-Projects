/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package computersupportapplication;

/**
 *
 * @author John Mc Dermott
 */
public class ComputerSupport {
    
}
